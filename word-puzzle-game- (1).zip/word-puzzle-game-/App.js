import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
  BackHandler,
  Dimensions,
  Animated,
  StatusBar,
  ScrollView,
} from "react-native";

const { width, height } = Dimensions.get("window");

const levels = [
  { id: 1, emoji: "🍎", answer: "APPLE" },
  { id: 2, emoji: "🍌", answer: "BANANA" },
  { id: 3, emoji: "🍇", answer: "GRAPES" },
  { id: 4, emoji: "🍊", answer: "ORANGE" },
  { id: 5, emoji: "🥭", answer: "MANGO" },
  { id: 6, emoji: "🐶", answer: "DOG" },
  { id: 7, emoji: "🐱", answer: "CAT" },
  { id: 8, emoji: "🐰", answer: "RABBIT" },
  { id: 9, emoji: "🐘", answer: "ELEPHANT" },
  { id: 10, emoji: "🦒", answer: "GIRAFFE" },
  { id: 11, emoji: "🚗", answer: "CAR" },
  { id: 12, emoji: "🚌", answer: "BUS" },
  { id: 13, emoji: "🚂", answer: "TRAIN" },
  { id: 14, emoji: "✈️", answer: "PLANE" },
  { id: 15, emoji: "🚢", answer: "SHIP" },
  { id: 16, emoji: "🏠", answer: "HOUSE" },
  { id: 17, emoji: "🏫", answer: "SCHOOL" },
  { id: 18, emoji: "🏥", answer: "HOSPITAL" },
  { id: 19, emoji: "🦁", answer: "LION" },
  { id: 20, emoji: "🌈", answer: "RAINBOW" },
  { id: 21, emoji: "⚽", answer: "BALL" },
  { id: 22, emoji: "🏏", answer: "BAT" },
  { id: 23, emoji: "🎾", answer: "TENNIS" },
  { id: 24, emoji: "🏀", answer: "BASKETBALL" },
  { id: 25, emoji: "🏈", answer: "FOOTBALL" },
  { id: 26, emoji: "🐦", answer: "BIRD" },
  { id: 27, emoji: "🦆", answer: "DUCK" },
  { id: 28, emoji: "🦉", answer: "OWL" },
  { id: 29, emoji: "🦅", answer: "EAGLE" },
  { id: 30, emoji: "🦜", answer: "PARROT" },
  { id: 31, emoji: "🐟", answer: "FISH" },
  { id: 32, emoji: "🐬", answer: "DOLPHIN" },
  { id: 33, emoji: "🦈", answer: "SHARK" },
  { id: 34, emoji: "🐙", answer: "OCTOPUS" },
  { id: 35, emoji: "🦀", answer: "CRAB" },
  { id: 36, emoji: "🥕", answer: "CARROT" },
  { id: 37, emoji: "🍅", answer: "TOMATO" },
  { id: 38, emoji: "🥔", answer: "POTATO" },
  { id: 39, emoji: "🌽", answer: "CORN" },
  { id: 40, emoji: "🥒", answer: "CUCUMBER" },
  { id: 41, emoji: "🔴", answer: "RED" },
  { id: 42, emoji: "🔵", answer: "BLUE" },
  { id: 43, emoji: "🟢", answer: "GREEN" },
  { id: 44, emoji: "🟡", answer: "YELLOW" },
  { id: 45, emoji: "🟣", answer: "PURPLE" },
  { id: 46, emoji: "1️⃣", answer: "ONE" },
  { id: 47, emoji: "2️⃣", answer: "TWO" },
  { id: 48, emoji: "3️⃣", answer: "THREE" },
  { id: 49, emoji: "4️⃣", answer: "FOUR" },
  { id: 50, emoji: "5️⃣", answer: "FIVE" },
];

export default function App() {
  const [screen, setScreen] = useState("home");
  const [currentLevel, setCurrentLevel] = useState(0);
  const [score, setScore] = useState(0);
  const [stars, setStars] = useState(0);
  const [unlocked, setUnlocked] = useState(1);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const bounceAnim = useRef(new Animated.Value(0)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  
  useEffect(() => {
    if (screen === "home") {
      // Start entrance animations
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 8,
          tension: 40,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 600,
          useNativeDriver: true,
        }),
      ]).start();
      
      // Bounce animation for play button
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.05,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
      
      // Continuous rotation for decorative elements
      Animated.loop(
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 20000,
          useNativeDriver: true,
        })
      ).start();
    }
  }, [screen]);

  useEffect(() => {
    const backAction = () => {
      if (screen !== "home") {
        setScreen("home");
        return true;
      }
      return false;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );

    return () => backHandler.remove();
  }, [screen]);

  const level = levels[currentLevel];

  const options = useMemo(() => {
    if (!level) return [];
    const allWords = levels.map((x) => x.answer);
    const wrong = allWords.filter((w) => w !== level.answer).slice(0, 3);
    return [level.answer, ...wrong].sort(() => Math.random() - 0.5);
  }, [currentLevel, level]);

  const checkAnswer = (word) => {
    if (word === level.answer) {
      setScore(score + 10);
      setStars(stars + 1);
      if (unlocked < levels.length && level.id >= unlocked) {
        setUnlocked(unlocked + 1);
      }

      if (currentLevel === levels.length - 1) {
        setScreen("winner");
      } else {
        Alert.alert("🎉 Correct!", "Awesome Job!", [
          { text: "Next Level", onPress: () => setCurrentLevel(currentLevel + 1) },
        ]);
      }
    } else {
      Alert.alert("❌ Wrong", "Try Again!");
    }
  };

  const resetGame = () => {
    setCurrentLevel(0);
    setScore(0);
    setStars(0);
    setUnlocked(1);
    setScreen("home");
  };

  const startGameFromFrontPage = () => {
    setCurrentLevel(0);
    setScore(0);
    setStars(0);
    setUnlocked(1);
    setScreen("levelSelect");
  };

  const renderLevelItem = ({ item, index }) => {
    const isUnlocked = index + 1 <= unlocked;
    const isCompleted = stars > index;

    return (
      <TouchableOpacity
        style={[
          styles.levelCard,
          !isUnlocked && styles.levelLocked,
          isCompleted && styles.levelCompleted,
        ]}
        onPress={() => {
          if (isUnlocked) {
            setCurrentLevel(index);
            setScreen("game");
          } else {
            Alert.alert("🔒 Locked", "Complete previous levels to unlock!");
          }
        }}
        disabled={!isUnlocked}
      >
        <Text style={styles.levelEmoji}>{item.emoji}</Text>
        <Text style={styles.levelNumber}>Level {item.id}</Text>
        {!isUnlocked && <Text style={styles.lockIcon}>🔒</Text>}
        {isCompleted && <Text style={styles.checkIcon}>✓</Text>}
      </TouchableOpacity>
    );
  };

  // ATTRACTIVE UNIQUE FRONT PAGE
  if (screen === "home") {
    const spin = rotateAnim.interpolate({
      inputRange: [0, 1],
      outputRange: ['0deg', '360deg']
    });
    
    return (
      <>
        <StatusBar barStyle="light-content" backgroundColor="#6B48FF" />
        <View style={styles.frontContainer}>
          {/* Animated Floating Particles */}
          <View style={styles.particlesContainer}>
            {[...Array(15)].map((_, i) => (
              <Animated.View
                key={i}
                style={[
                  styles.particle,
                  {
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    width: 3 + Math.random() * 6,
                    height: 3 + Math.random() * 6,
                    opacity: 0.3 + Math.random() * 0.5,
                  },
                ]}
              />
            ))}
          </View>
          
          {/* Animated Decorative Circles */}
          <Animated.View style={[styles.decorCircle1, { transform: [{ rotate: spin }] }]} />
          <Animated.View style={[styles.decorCircle2, { transform: [{ rotate: spin }] }]} />
          <Animated.View style={[styles.decorCircle3, { transform: [{ rotate: spin }] }]} />
          <View style={styles.decorCircle4} />
          <View style={styles.decorCircle5} />
          
          <Animated.View 
            style={[
              styles.frontContent,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              }
            ]}
          >
            {/* Animated Emoji Header */}
            <View style={styles.emojiHeader}>
              <Animated.Text style={[styles.headerEmoji, { transform: [{ scale: scaleAnim }] }]}>
                🎮
              </Animated.Text>
              <Animated.Text style={[styles.headerEmoji, { transform: [{ scale: scaleAnim }] }]}>
                🧩
              </Animated.Text>
              <Animated.Text style={[styles.headerEmoji, { transform: [{ scale: scaleAnim }] }]}>
                ✨
              </Animated.Text>
            </View>
            
            {/* Title Section with Gradient Effect using Text */}
            <View style={styles.titleContainer}>
              <Text style={styles.frontTitle}>
                <Text style={styles.titleGradient}>WORD</Text>
                {"\n"}
                <Text style={styles.titleAccent}>PUZZLE</Text>
              </Text>
              <View style={styles.titleUnderline} />
            </View>
            
            {/* Subtitle */}
            <Text style={styles.frontSubtitle}>
              Can you guess the word from the emoji? 🔍
            </Text>
            
            {/* Stats Preview Card */}
            <View style={styles.statsGlassCard}>
              <View style={styles.frontStatItem}>
                <View style={styles.statIconBg}>
                  <Text style={styles.frontStatEmoji}>⭐</Text>
                </View>
                <Text style={styles.frontStatValue}>{stars}</Text>
                <Text style={styles.statLabel}>Stars</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.frontStatItem}>
                <View style={styles.statIconBg}>
                  <Text style={styles.frontStatEmoji}>🏆</Text>
                </View>
                <Text style={styles.frontStatValue}>{score}</Text>
                <Text style={styles.statLabel}>Score</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.frontStatItem}>
                <View style={styles.statIconBg}>
                  <Text style={styles.frontStatEmoji}>🔓</Text>
                </View>
                <Text style={styles.frontStatValue}>{unlocked}/{levels.length}</Text>
                <Text style={styles.statLabel}>Unlocked</Text>
              </View>
            </View>
            
            {/* Animated PLAY Button */}
            <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
              <TouchableOpacity 
                activeOpacity={0.8}
                onPress={startGameFromFrontPage}
                style={styles.playButtonWrapper}
              >
                <View style={styles.playButton}>
                  <Text style={styles.playButtonText}>🎯 PLAY NOW</Text>
                </View>
              </TouchableOpacity>
            </Animated.View>
            
            {/* Feature Highlights */}
            <View style={styles.featuresContainer}>
              <View style={styles.featureItem}>
                <Text style={styles.featureEmoji}>🎨</Text>
                <Text style={styles.featureText}>50+ Levels</Text>
              </View>
              <View style={styles.featureDot} />
              <View style={styles.featureItem}>
                <Text style={styles.featureEmoji}>⭐</Text>
                <Text style={styles.featureText}>Collect Stars</Text>
              </View>
              <View style={styles.featureDot} />
              <View style={styles.featureItem}>
                <Text style={styles.featureEmoji}>🏆</Text>
                <Text style={styles.featureText}>Leaderboard</Text>
              </View>
            </View>
            
            {/* Footer */}
            <Text style={styles.frontFooter}>
              Match the emoji with the correct word!
            </Text>
          </Animated.View>
        </View>
      </>
    );
  }

  // LEVEL SELECT SCREEN
  if (screen === "levelSelect") {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => setScreen("home")} style={styles.homeBackButton}>
            <Text style={styles.homeBackButtonText}>← Home</Text>
          </TouchableOpacity>
          <Text style={styles.title}>🧩 Select Level</Text>
          <Text style={styles.subtitle}>Choose a level to play!</Text>
        </View>
        <View style={styles.statsBar}>
          <View style={styles.statItem}>
            <Text style={styles.statLabel}>⭐ Stars</Text>
            <Text style={styles.statValue}>{stars}</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statLabel}>🏆 Score</Text>
            <Text style={styles.statValue}>{score}</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statLabel}>🔓 Unlocked</Text>
            <Text style={styles.statValue}>{unlocked}/{levels.length}</Text>
          </View>
        </View>
        <FlatList
          data={levels}
          renderItem={renderLevelItem}
          keyExtractor={(item) => item.id.toString()}
          numColumns={2}
          contentContainerStyle={styles.levelList}
          showsVerticalScrollIndicator={false}
        />
      </SafeAreaView>
    );
  }

  // GAME SCREEN
  if (screen === "game") {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.gameHeader}>
          <TouchableOpacity onPress={() => setScreen("levelSelect")} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Levels</Text>
          </TouchableOpacity>
          <View style={styles.gameStats}>
            <Text style={styles.gameStat}>⭐ {stars}</Text>
            <Text style={styles.gameStat}>🏆 {score}</Text>
            <Text style={styles.gameStat}>Level {level.id}/{levels.length}</Text>
          </View>
        </View>
        <View style={styles.gameContent}>
          <Text style={styles.emojiDisplay}>{level.emoji}</Text>
          <Text style={styles.promptText}>What is this?</Text>
          <View style={styles.optionsContainer}>
            {options.map((word, idx) => (
              <TouchableOpacity
                key={idx}
                style={styles.optionButton}
                onPress={() => checkAnswer(word)}
              >
                <Text style={styles.optionText}>{word}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // WINNER SCREEN
  if (screen === "winner") {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.winnerContent}>
          <Text style={styles.winnerEmoji}>🏆🎉👏</Text>
          <Text style={styles.winnerTitle}>You Won!</Text>
          <Text style={styles.winnerText}>
            Congratulations! You completed all {levels.length} levels.
          </Text>
          <Text style={styles.finalScore}>Final Score: {score}</Text>
          <Text style={styles.finalStars}>Stars Collected: {stars}</Text>
          <TouchableOpacity style={styles.playAgainButton} onPress={resetGame}>
            <Text style={styles.playAgainText}>Play Again</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={() => {
              setScreen("home");
              setCurrentLevel(0);
            }}
          >
            <Text style={styles.homeButtonText}>Back to Home</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  // ATTRACTIVE FRONT PAGE STYLES
  frontContainer: {
    flex: 1,
    backgroundColor: "#6B48FF",
  },
  particlesContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  particle: {
    position: 'absolute',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
  },
  frontContent: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
  },
  decorCircle1: {
    position: "absolute",
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: "rgba(255, 255, 255, 0.08)",
    top: -100,
    right: -80,
  },
  decorCircle2: {
    position: "absolute",
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: "rgba(255, 255, 255, 0.06)",
    bottom: -60,
    left: -60,
  },
  decorCircle3: {
    position: "absolute",
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "rgba(255, 215, 0, 0.08)",
    bottom: '20%',
    right: '10%',
  },
  decorCircle4: {
    position: "absolute",
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    top: '30%',
    left: '-10%',
  },
  decorCircle5: {
    position: "absolute",
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "rgba(255, 215, 0, 0.06)",
    bottom: '15%',
    left: '15%',
  },
  emojiHeader: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 25,
  },
  headerEmoji: {
    fontSize: 40,
    textShadowColor: 'rgba(0,0,0,0.2)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 5,
  },
  titleContainer: {
    alignItems: "center",
    marginBottom: 20,
  },
  frontTitle: {
    fontSize: 56,
    fontWeight: "bold",
    textAlign: "center",
    lineHeight: 65,
  },
  titleGradient: {
    color: "#FFD700",
    textShadowColor: "rgba(0, 0, 0, 0.3)",
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 8,
  },
  titleAccent: {
    color: "#FFFFFF",
    textShadowColor: "rgba(0, 0, 0, 0.3)",
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 8,
  },
  titleUnderline: {
    width: 80,
    height: 4,
    backgroundColor: "#FFD700",
    borderRadius: 2,
    marginTop: 15,
  },
  frontSubtitle: {
    fontSize: 17,
    color: "#FFFFFF",
    opacity: 0.95,
    marginBottom: 40,
    textAlign: "center",
    letterSpacing: 0.5,
    fontWeight: "500",
  },
  statsGlassCard: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "rgba(255, 255, 255, 0.15)",
    borderRadius: 30,
    paddingVertical: 20,
    paddingHorizontal: 15,
    marginBottom: 45,
    width: "100%",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.25)",
  },
  frontStatItem: {
    alignItems: "center",
    flex: 1,
  },
  statIconBg: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  frontStatEmoji: {
    fontSize: 26,
  },
  frontStatValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFD700",
    marginTop: 2,
  },
  statLabel: {
    fontSize: 12,
    color: "#FFFFFF",
    opacity: 0.85,
    marginTop: 2,
    fontWeight: "500",
  },
  statDivider: {
    width: 1,
    height: 45,
    backgroundColor: "rgba(255, 255, 255, 0.3)",
  },
  playButtonWrapper: {
    marginBottom: 40,
    shadowColor: "#FFD700",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 10,
  },
  playButton: {
    backgroundColor: "#FFD700",
    paddingVertical: 18,
    paddingHorizontal: 45,
    borderRadius: 50,
    alignItems: "center",
  },
  playButtonText: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#6B48FF",
    letterSpacing: 2,
  },
  featuresContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 35,
    flexWrap: "wrap",
  },
  featureItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  featureEmoji: {
    fontSize: 18,
  },
  featureText: {
    fontSize: 14,
    color: "#FFFFFF",
    opacity: 0.9,
    fontWeight: "600",
  },
  featureDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: "#FFD700",
    opacity: 0.8,
    marginHorizontal: 12,
  },
  frontFooter: {
    fontSize: 13,
    color: "#FFFFFF",
    opacity: 0.7,
    position: "absolute",
    bottom: 30,
    textAlign: "center",
  },

  // EXISTING GAME STYLES
  container: {
    flex: 1,
    backgroundColor: "#f0f8ff",
  },
  header: {
    alignItems: "center",
    paddingVertical: 20,
    backgroundColor: "#4caf50",
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    marginBottom: 15,
  },
  homeBackButton: {
    position: "absolute",
    left: 20,
    top: 20,
    backgroundColor: "#fff",
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    zIndex: 1,
  },
  homeBackButtonText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#4caf50",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#fff",
  },
  subtitle: {
    fontSize: 16,
    color: "#fff",
    marginTop: 5,
  },
  statsBar: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 12,
    backgroundColor: "#fff",
    marginHorizontal: 15,
    borderRadius: 15,
    marginBottom: 15,
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  statItem: {
    alignItems: "center",
  },
  statLabel: {
    fontSize: 13,
    color: "#666",
  },
  statValue: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#4caf50",
  },
  levelList: {
    paddingHorizontal: 10,
    paddingBottom: 20,
  },
  levelCard: {
    flex: 1,
    margin: 8,
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 15,
    alignItems: "center",
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    minWidth: (width - 60) / 2,
  },
  levelLocked: {
    backgroundColor: "#e0e0e0",
    opacity: 0.7,
  },
  levelCompleted: {
    backgroundColor: "#c8e6c9",
    borderWidth: 2,
    borderColor: "#4caf50",
  },
  levelEmoji: {
    fontSize: 40,
    marginBottom: 8,
  },
  levelNumber: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  lockIcon: {
    position: "absolute",
    top: 10,
    right: 10,
    fontSize: 18,
  },
  checkIcon: {
    position: "absolute",
    top: 10,
    right: 10,
    fontSize: 18,
    color: "#4caf50",
  },
  gameHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: "#4caf50",
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  backButton: {
    backgroundColor: "#fff",
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#4caf50",
  },
  gameStats: {
    flexDirection: "row",
    gap: 15,
  },
  gameStat: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#fff",
  },
  gameContent: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  emojiDisplay: {
    fontSize: 100,
    marginBottom: 20,
  },
  promptText: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 40,
  },
  optionsContainer: {
    width: "100%",
    gap: 15,
  },
  optionButton: {
    backgroundColor: "#fff",
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ddd",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  optionText: {
    fontSize: 18,
    fontWeight: "600",
    color: "#4caf50",
  },
  winnerContent: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 30,
  },
  winnerEmoji: {
    fontSize: 60,
    marginBottom: 20,
  },
  winnerTitle: {
    fontSize: 36,
    fontWeight: "bold",
    color: "#4caf50",
    marginBottom: 15,
  },
  winnerText: {
    fontSize: 18,
    textAlign: "center",
    color: "#666",
    marginBottom: 20,
  },
  finalScore: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#ff9800",
    marginBottom: 10,
  },
  finalStars: {
    fontSize: 20,
    color: "#ffc107",
    marginBottom: 30,
  },
  playAgainButton: {
    backgroundColor: "#4caf50",
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 30,
    marginBottom: 15,
    width: "100%",
    alignItems: "center",
  },
  playAgainText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  homeButton: {
    backgroundColor: "#2196f3",
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 30,
    width: "100%",
    alignItems: "center",
  },
  homeButtonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
});